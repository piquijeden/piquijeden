import tkinter as tk
import random
import subprocess
import threading
import os


class JanuszGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Pierbonka")
        self.root.geometry("800x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#f5f1e8")

        self.canvas = tk.Canvas(root, width=800, height=550, bg="#f5f1e8", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        self.width = 800
        self.height = 600

        self.score = 0
        self.lives = 3
        self.game_over = False
        self.paused = False

        self.janusz_x = 420
        self.janusz_speed = 50

        self.basket_width = 150
        self.basket_height = 38

        self.product = None
        self.product_speed = 6
        self.product_size = 52
        self.product_name = ""
        self.product_color = "#ff6666"

        self.products = [
            ("Chleb", "#d9a55a"),
            ("Mleko", "#bfe3ff"),
            ("Ser", "#ffd95e"),
            ("Cebula", "#f3e04f"),
            ("Czteropak", "#ff9b3d"),
            ("Parówki", "#de6b6b"),
            ("Wódka", "#7ccf6a"),
            ("Masło", "#fff2a8"),
        ]

        self.pause_buttons = {}

        self.music_file = os.path.join(os.path.dirname(__file__), "muzyka.mp3")
        self.music_volume = 0.50
        self.music_running = False
        self.music_thread = None
        self.music_process = None

        self.volume_slider = None
        self.volume_label = None

        self.root.bind("<Left>", self.move_left)
        self.root.bind("<Right>", self.move_right)
        self.root.bind("<Escape>", self.toggle_pause)
        self.root.bind("<Key-r>", self.restart_game)
        self.canvas.bind("<Button-1>", self.on_mouse_click)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        self.spawn_product()
        self.start_music()
        self.draw()
        self.update_game()

    # =========================
    # MUZYKA
    # =========================

    def music_loop(self):
        while self.music_running:
            if not os.path.exists(self.music_file):
                break

            try:
                self.music_process = subprocess.Popen(
                    ["afplay", "-v", str(self.music_volume), self.music_file],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
                self.music_process.wait()
            except Exception:
                break

    def start_music(self):
        if not os.path.exists(self.music_file):
            print("Brak pliku muzyki:", self.music_file)
            return

        if self.music_running:
            return

        self.music_running = True
        self.music_thread = threading.Thread(target=self.music_loop, daemon=True)
        self.music_thread.start()

    def stop_music(self):
        self.music_running = False

        if self.music_process and self.music_process.poll() is None:
            try:
                self.music_process.terminate()
            except Exception:
                pass

        self.music_process = None

    def restart_music_with_new_volume(self):
        self.stop_music()
        self.start_music()

    def on_close(self):
        self.hide_volume_slider()
        self.stop_music()
        self.root.destroy()

    # =========================
    # SUWAK GŁOŚNOŚCI
    # =========================

    def show_volume_slider(self):
        if self.volume_slider is None:
            self.volume_slider = tk.Scale(
                self.root,
                from_=0,
                to=100,
                orient="horizontal",
                length=220,
                bg="white",
                fg="black",
                highlightthickness=0,
                bd=2,
                font=("Arial", 10),
                command=self.on_volume_change
            )
            self.volume_slider.set(int(self.music_volume * 100))

        if self.volume_label is None:
            self.volume_label = tk.Label(
                self.root,
                text="Głośność muzyki",
                font=("Arial", 12, "bold"),
                bg="white",
                fg="black"
            )

        self.update_slider_position()

    def hide_volume_slider(self):
        if self.volume_slider:
            self.volume_slider.place_forget()
        if self.volume_label:
            self.volume_label.place_forget()

    def update_slider_position(self):
        if self.paused and self.volume_slider and self.volume_label:
            self.volume_label.place(
                x=self.width / 2 - 85,
                y=self.height / 2 + 105
            )
            self.volume_slider.place(
                x=self.width / 2 - 110,
                y=self.height / 2 + 125
            )

    def on_volume_change(self, value):
        new_volume = max(0.0, min(1.0, int(value) / 100))
        if abs(new_volume - self.music_volume) > 0.001:
            self.music_volume = new_volume
            self.restart_music_with_new_volume()
            self.draw()

    # =========================
    # RUCH
    # =========================

    def move_left(self, event=None):
        if self.game_over or self.paused:
            return
        min_x = -85
        self.janusz_x = max(min_x, self.janusz_x - self.janusz_speed)
        self.draw()

    def move_right(self, event=None):
        if self.game_over or self.paused:
            return
        max_x = self.width - self.basket_width - 55
        self.janusz_x = min(max_x, self.janusz_x + self.janusz_speed)
        self.draw()

    def toggle_pause(self, event=None):
        if self.game_over:
            return

        self.paused = not self.paused

        if self.paused:
            self.show_volume_slider()
        else:
            self.hide_volume_slider()

        self.draw()

    # =========================
    # GRA
    # =========================

    def spawn_product(self):
        name, color = random.choice(self.products)

        # spawn w zasięgu koszyka
        min_spawn_x = 0
        max_spawn_x = max(10, self.width - self.product_size)
        x = random.randint(min_spawn_x, max_spawn_x)

        self.product = {
            "x": x,
            "y": 120,
            "size": self.product_size
        }
        self.product_name = name
        self.product_color = color

    def get_basket_rect(self):
        y = self.height - 220
        bx1 = self.janusz_x + 55
        by1 = y + 110
        bx2 = bx1 + self.basket_width
        by2 = by1 + self.basket_height
        return bx1, by1, bx2, by2

    def check_collision(self):
        if not self.product:
            return False

        px1 = self.product["x"]
        py1 = self.product["y"]
        px2 = px1 + self.product["size"]
        py2 = py1 + self.product["size"]

        bx1, by1, bx2, by2 = self.get_basket_rect()

        return px2 > bx1 and px1 < bx2 and py2 > by1 and py1 < by2

    def update_game(self):
        if not self.game_over and not self.paused:
            if self.product:
                self.product["y"] += self.product_speed

                if self.check_collision():
                    self.score += 1

                    if self.score % 5 == 0:
                        self.product_speed += 0.4

                    self.spawn_product()

                elif self.product["y"] > self.height:
                    self.lives -= 1
                    if self.lives <= 0:
                        self.game_over = True
                    else:
                        self.spawn_product()

            self.draw()

        self.root.after(30, self.update_game)

    def restart_game(self, event=None):
        self.score = 0
        self.lives = 3
        self.game_over = False
        self.paused = False
        self.product_speed = 6
        self.janusz_x = self.width // 2 - 80
        self.hide_volume_slider()
        self.spawn_product()
        self.draw()

    def restart_from_pause(self):
        self.restart_game()

    # =========================
    # KLIKANIE W MENU PAUZY
    # =========================

    def on_mouse_click(self, event):
        if not self.paused:
            return

        x, y = event.x, event.y

        if "continue" in self.pause_buttons:
            x1, y1, x2, y2 = self.pause_buttons["continue"]
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.paused = False
                self.hide_volume_slider()
                self.draw()
                return

        if "restart" in self.pause_buttons:
            x1, y1, x2, y2 = self.pause_buttons["restart"]
            if x1 <= x <= x2 and y1 <= y <= y2:
                self.restart_from_pause()
                return

    # =========================
    # RYSOWANIE
    # =========================

    def draw_background(self):
        self.canvas.create_rectangle(0, 0, self.width, self.height, fill="#f5f1e8", outline="")
        self.canvas.create_rectangle(0, self.height - 120, self.width, self.height, fill="#d8d8d8", outline="")

        shelf_w = self.width // 4
        self.canvas.create_rectangle(40, 70, 40 + shelf_w, 170, fill="#ffe14d", outline="#333", width=3)
        self.canvas.create_rectangle(80 + shelf_w, 70, 80 + shelf_w * 2, 170, fill="#ff5757", outline="#333", width=3)
        self.canvas.create_rectangle(120 + shelf_w * 2, 70, 120 + shelf_w * 3, 170, fill="#7fd36b", outline="#333", width=3)

        self.canvas.create_text(40 + shelf_w / 2, 120, text="PROMOCJE", font=("Arial", 20, "bold"))
        self.canvas.create_text(80 + shelf_w * 1.5, 120, text="NABIAŁ", font=("Arial", 20, "bold"))
        self.canvas.create_text(120 + shelf_w * 2.5, 120, text="ALKOHOLE", font=("Arial", 20, "bold"))

    def draw_janusz_with_basket(self):
        x = self.janusz_x
        y = self.height - 220

        self.canvas.create_line(x - 20, y + 150, x - 25, y + 190, width=5, fill="black")
        self.canvas.create_line(x + 20, y + 150, x + 25, y + 190, width=5, fill="black")

        self.canvas.create_rectangle(x - 40, y + 70, x + 40, y + 150, fill="#4d83ff", outline="black", width=2)

        self.canvas.create_line(x - 40, y + 85, x - 80, y + 110, width=5, fill="black")
        self.canvas.create_line(x + 40, y + 85, x + 70, y + 110, width=5, fill="black")

        self.canvas.create_oval(x - 35, y, x + 35, y + 70, fill="#f0c9a0", outline="black", width=2)

        self.canvas.create_oval(x - 18, y + 22, x - 10, y + 30, fill="black")
        self.canvas.create_oval(x + 10, y + 22, x + 18, y + 30, fill="black")

        self.canvas.create_oval(x + 5, y + 28, x + 32, y + 46, fill="#d8a98d", outline="black")
        self.canvas.create_arc(x - 22, y + 36, x + 10, y + 56, start=180, extent=180, style="arc", width=3)
        self.canvas.create_arc(x - 24, y + 5, x + 24, y + 25, start=0, extent=180, style="arc", width=3)

        bx1 = x + 55
        by1 = y + 110
        bx2 = bx1 + self.basket_width
        by2 = by1 + self.basket_height

        self.canvas.create_rectangle(bx1, by1, bx2, by2, fill="#9c6736", outline="black", width=2)
        self.canvas.create_arc(bx1 + 15, by1 - 18, bx2 - 15, by1 + 10, start=0, extent=180, style="arc", width=3)

        for i in range(1, 6):
            line_x = bx1 + i * (self.basket_width / 6)
            self.canvas.create_line(line_x, by1 + 3, line_x, by2 - 3, width=2, fill="#5b3a1f")

        self.canvas.create_line(bx1 + 5, by1 + 12, bx2 - 5, by1 + 12, width=2, fill="#5b3a1f")
        self.canvas.create_line(bx1 + 5, by1 + 25, bx2 - 5, by1 + 25, width=2, fill="#5b3a1f")

        self.canvas.create_text(x, y + 205, text="Janusz", font=("Arial", 16, "bold"))

    def draw_product(self):
        if not self.product:
            return

        x = self.product["x"]
        y = self.product["y"]
        s = self.product["size"]

        self.canvas.create_rectangle(x, y, x + s, y + s, fill=self.product_color, outline="black", width=2)
        self.canvas.create_text(
            x + s / 2,
            y + s / 2,
            text=self.product_name,
            font=("Arial", 9, "bold"),
            width=s - 6
        )

    def draw_ui(self):
        self.canvas.create_text(110, 30, text=f"Punkty: {self.score}", font=("Arial", 20, "bold"), fill="black")
        self.canvas.create_text(105, 60, text=f"Życia: {self.lives}", font=("Arial", 20, "bold"), fill="black")

        self.canvas.create_text(
            self.width / 2,
            30,
            text="Cel: Łap promocje w Pierbonce",
            font=("Arial", 24, "bold"),
            fill="black"
        )

        self.canvas.create_text(
            self.width / 2,
            self.height - 20,
            text="Sterowanie: strzałki lewo/prawo | ESC - pauza | R - restart",
            font=("Arial", 14),
            fill="black"
        )

    def draw_game_over(self):
        self.canvas.create_rectangle(
            self.width / 2 - 220, self.height / 2 - 100,
            self.width / 2 + 220, self.height / 2 + 100,
            fill="white", outline="black", width=3
        )

        self.canvas.create_text(
            self.width / 2, self.height / 2 - 40,
            text="KONIEC GRY",
            font=("Arial", 28, "bold"),
            fill="red"
        )

        self.canvas.create_text(
            self.width / 2, self.height / 2,
            text=f"Twój wynik: {self.score}",
            font=("Arial", 20, "bold"),
            fill="black"
        )

        self.canvas.create_text(
            self.width / 2, self.height / 2 + 40,
            text="Naciśnij R, aby zagrać ponownie",
            font=("Arial", 16),
            fill="black"
        )

    def draw_pause_menu(self):
        self.pause_buttons = {}

        self.canvas.create_rectangle(0, 0, self.width, self.height, fill="black", stipple="gray50", outline="")

        box_x1 = self.width / 2 - 185
        box_y1 = self.height / 2 - 140
        box_x2 = self.width / 2 + 185
        box_y2 = self.height / 2 + 200

        self.canvas.create_rectangle(box_x1, box_y1, box_x2, box_y2, fill="white", outline="black", width=3)

        self.canvas.create_text(
            self.width / 2, self.height / 2 - 90,
            text="PAUZA",
            font=("Arial", 28, "bold"),
            fill="black"
        )

        cont_x1 = self.width / 2 - 110
        cont_y1 = self.height / 2 - 20
        cont_x2 = self.width / 2 + 110
        cont_y2 = self.height / 2 + 30

        self.canvas.create_rectangle(cont_x1, cont_y1, cont_x2, cont_y2, fill="#7fd36b", outline="black", width=2)
        self.canvas.create_text(
            self.width / 2, self.height / 2 + 5,
            text="Kontynuuj",
            font=("Arial", 18, "bold"),
            fill="black"
        )
        self.pause_buttons["continue"] = (cont_x1, cont_y1, cont_x2, cont_y2)

        rest_x1 = self.width / 2 - 110
        rest_y1 = self.height / 2 + 55
        rest_x2 = self.width / 2 + 110
        rest_y2 = self.height / 2 + 105

        self.canvas.create_rectangle(rest_x1, rest_y1, rest_x2, rest_y2, fill="#ff8a8a", outline="black", width=2)
        self.canvas.create_text(
            self.width / 2, self.height / 2 + 80,
            text="Restart",
            font=("Arial", 18, "bold"),
            fill="black"
        )
        self.pause_buttons["restart"] = (rest_x1, rest_y1, rest_x2, rest_y2)

        self.canvas.create_text(
            self.width / 2,
            self.height / 2 + 138,
            text=f"Głośność: {int(self.music_volume * 100)}%",
            font=("Arial", 12, "bold"),
            fill="black"
        )

    def draw(self):
        self.canvas.delete("all")
        self.draw_background()
        self.draw_janusz_with_basket()
        self.draw_product()
        self.draw_ui()

        if self.game_over:
            self.draw_game_over()

        if self.paused and not self.game_over:
            self.draw_pause_menu()


if __name__ == "__main__":
    root = tk.Tk()
    game = JanuszGame(root)
    root.mainloop()
